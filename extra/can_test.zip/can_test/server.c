#include <string.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <linux/can.h>

#ifndef PF_CAN
#define PF_CAN 29
#endif

#ifndef AF_CAN
#define AF_CAN PF_CAN
#endif

int main()
{
	int s;
	unsigned long nbytes,len;
	struct sockaddr_can addr;
	struct ifreq ifr;
	struct can_frame frame;


	s = socket(PF_CAN,SOCK_RAW,CAN_RAW);

	strcpy(ifr.ifr_name,"can0");
	ioctl(s,SIOCGIFINDEX,&ifr);
	printf("can0 can_ifindex = %x\n",ifr.ifr_ifindex);

	//bind to all enabled can interface
	addr.can_family = AF_CAN;
	addr.can_ifindex =0;
	bind(s,(struct sockaddr*)&addr,sizeof(addr));

	nbytes = recvfrom(s,&frame,sizeof(struct can_frame),0,(struct sockaddr *)&addr,&len);
	
	/*get interface name of the received CAN frame*/
	ifr.ifr_ifindex = addr.can_ifindex;
	ioctl(s,SIOCGIFNAME,&ifr);
	printf("Received a CAN frame from interface %s\n",ifr.ifr_name);
	printf("frame message\n"
		"--can_id = %x\n"
		"--can_dlc = %x\n"
		"--data = %s\n",frame.can_id,frame.can_dlc,frame.data);

	return 0;
}
