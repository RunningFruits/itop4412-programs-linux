#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/usb/input.h>
#include <linux/hid.h>

static void check_usb_device_descriptor(struct usb_device *dev)
{
	printk("dev->descriptor.idVendor is %4x!\n\
		dev->descriptor.idProduct is %4x!\n\
		dev->descriptor.bcdDevice is %4x!\n\
		dev->descriptor.iSerialNumber is %2x!\n",\
	dev->descriptor.idVendor,dev->descriptor.idProduct,dev->descriptor.bcdDevice,dev->descriptor.iSerialNumber);
}

static int usb_mouse_probe(struct usb_interface *intf, const struct usb_device_id *id)
{
	struct usb_device *dev = interface_to_usbdev(intf);

	
	printk("usb mouse probe!\n");
	check_usb_device_descriptor(dev);
	
	return 0;
}

static void usb_mouse_disconnect(struct usb_interface *intf)
{
	printk("usb mouse disconnect!\n");
}

static struct usb_device_id usb_mouse_id_table [] = {
	{ USB_INTERFACE_INFO(USB_INTERFACE_CLASS_HID, USB_INTERFACE_SUBCLASS_BOOT,
		USB_INTERFACE_PROTOCOL_MOUSE) },
	{ }	/* Terminating entry */
};

MODULE_DEVICE_TABLE (usb, usb_mouse_id_table);

static struct usb_driver my_usb_mouse_driver = {
	.name		= "usbmouse",
	.probe		= usb_mouse_probe,
	.disconnect	= usb_mouse_disconnect,
	.id_table	= usb_mouse_id_table,
};

static int __init my_usb_mouse_init(void)
{
	//ע��usb����
	return usb_register(&my_usb_mouse_driver);
}

static void __exit my_usb_mouse_exit(void)
{
	//ж��USB����
	usb_deregister(&my_usb_mouse_driver);
}

module_init(my_usb_mouse_init);
module_exit(my_usb_mouse_exit);

MODULE_LICENSE("GPL");
